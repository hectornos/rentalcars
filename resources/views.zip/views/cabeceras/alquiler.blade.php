<tr>
  <td width="150" title="Fecha del alquiler" align="center"><a href="{{ route('Alquiler.index',['criterio' => 'fecha'] )}}" ><b>Fecha</b></a></td>
  <td width="150" align="center" title="Datos conductor"><a href="{{ route('Alquiler.index',['criterio' => 'conductor'] )}}" ><b>Conductor</b></a></td>
  <td width="150" align="center" title="Matricula"><a href="{{ route('Alquiler.index',['criterio' => 'matricula'] )}}" ><b>Matricula</b></a></td>
  <td width="150" align="center" title="Incidencias sufridas"><a href="{{ route('Alquiler.index',['criterio'=>'incidencias']) }}"><b>Incidencias</b></a></td>
  <td width="150" align="center"><b>Añade incidencia</b></td>
  <td width="150" align="center"><b>Eliminar</b></td>
  <td width="150" align="center"><b>Imprimir</b></td>
</tr>