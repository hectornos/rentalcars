<tr>
  <td width="150" title="Conductor del vehiculo" align="center"><b>Conductor</b></a></td>
  <td width="150" align="center" title="Datos vehiculo"><b>Matricula</b></a></td>
  <td width="150" align="center" title="Fecha incidencia"><b>Fecha</b></td>
  <td width="150" align="center" title="Descripcion de la incidencia"><b>Descripccion</b></a></td>
  <td width="150" align="center" title="Incidencia resuelta o no"><b>Resuelta</b></a></td>
  <td width="150" align="center"><b>Editar</b></td>
  <td width="150" align="center"><b>Eliminar</b></td>
  <td width="150" align="center"><b>Imprimir</b></td>
</tr>