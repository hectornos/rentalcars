<tr>
  <td width="150" title="Fecha del alquiler" align="center"><b>Fecha</b></a></td>
  <td width="150" align="center" title="Datos conductor"><b>Conductor</b></a></td>
  <td width="150" align="center" title="Matricula"><b>Matricula</b></a></td>
  <td width="150" align="center" title="Incidencias sufridas"><b>Incidencias</b></a></td>
  <td width="150" align="center"><b>Añade incidencia</b></td>
  <td width="150" align="center"><b>Eliminar</b></td>
  <td width="150" align="center"><b>Imprimir</b></td>
</tr>