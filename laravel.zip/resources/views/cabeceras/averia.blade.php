<tr>
  <td width="150" title="tipo de averia" align="center"><a href="{{ route('Averia.index',['criterio' => 'tipo'] )}}" ><b>Tipo</b></a></td>
  <td width="150" align="center" title="Datos vehiculo"><a href="{{ route('Averia.index',['criterio' => 'matricula'] )}}" ><b>Vehiculo</b></a></td>
  <td width="150" align="center" title="Breve descripcion"><b>Desccripcion</b></td>
  <td width="150" align="center" title="Fecha de la averia"><a href="{{ route('Averia.index',['criterio'=>'fecha']) }}"><b>Fecha</b></a></td>
  <td width="150" align="center"><b>Editar</b></td>
  <td width="150" align="center"><b>Eliminar</b></td>
  <td width="150" align="center"><b>Imprimir</b></td>
</tr>